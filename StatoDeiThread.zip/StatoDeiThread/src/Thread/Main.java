package Thread;


import java.util.Random;

class ContatoreThread extends Thread {
    private int maxValue;  // X, il valore massimo che il thread deve contare
    private int currentValue;  // Il valore corrente a cui il thread è arrivato

    public ContatoreThread(int maxValue) {
        this.maxValue = maxValue;
        this.currentValue = 0;
    }

    @Override
    public void run() {
        try {
            while (currentValue <= maxValue) {
                // Conta fino a maxValue
                Thread.sleep(120);  // Attendi 120ms
                currentValue++;
            }
        } catch (InterruptedException e) {
            System.out.println("Thread interrotto.");
        }
    }

    public int getCurrentValue() {
        return currentValue;
    }

    public int getMaxValue() {
        return maxValue;
    }
}

public class Main {
    public static void main(String[] args) throws InterruptedException {
        java.util.Scanner scanner = new java.util.Scanner(System.in);
        System.out.print("Inserisci il numero di thread (T): ");
        int T = scanner.nextInt();
        System.out.print("Inserisci il valore massimo (N): ");
        int N = scanner.nextInt();

        // Crea un array di thread
        ContatoreThread[] threads = new ContatoreThread[T];

        // Crea un oggetto Random per generare numeri casuali
        Random random = new Random();

        // Crea i thread
        for (int i = 0; i < T; i++) {
            int X = random.nextInt(N + 1);  // Genera un valore casuale tra 0 e N
            threads[i] = new ContatoreThread(X);
            threads[i].start();  // Avvia il thread
        }

        boolean tuttiCompletati = false;

        // Loop finché tutti i thread non sono completati
        while (!tuttiCompletati) {
            // Stampa lo stato di ciascun thread
            tuttiCompletati = true;  // Assume che siano tutti completati, verifica dopo
            for (int i = 0; i < T; i++) {
                if (threads[i].isAlive()) {
                    System.out.println("Thread " + (i + 1) + " sta contando: " + threads[i].getCurrentValue() + "/" + threads[i].getMaxValue());
                    tuttiCompletati = false;  // Se un thread è ancora attivo, non sono tutti completati
                } else {
                    System.out.println("Thread " + (i + 1) + " COMPLETATO");
                }
            }

            // Attendi 1 secondo prima di stampare di nuovo
            Thread.sleep(1000);
        }

        // Aspetta che tutti i thread finiscano
        for (int i = 0; i < T; i++) {
            threads[i].join();
        }

        System.out.println("TUTTI I THREAD COMPLETATI");
    }
}